// Populates sample data so the bot is demoable end-to-end.
// Edit these arrays (or write your own seed) with the school's real courses,
// slots, students and fees before going live.
require("dotenv").config();
const db = require("./index");

const insertCourse = db.prepare(`
  INSERT INTO courses (name, category, age_group, description, fee_text, duration_text)
  VALUES (@name, @category, @age_group, @description, @fee_text, @duration_text)
`);

const insertSlot = db.prepare(`
  INSERT INTO trial_slots (course_id, label, capacity, booked_count)
  VALUES (@course_id, @label, @capacity, 0)
`);

const insertSchedule = db.prepare(`
  INSERT INTO class_schedule (course_id, day_of_week, time_label, room)
  VALUES (@course_id, @day_of_week, @time_label, @room)
`);

const insertStudent = db.prepare(`
  INSERT OR IGNORE INTO students (phone, name, course_id, status)
  VALUES (@phone, @name, @course_id, 'active')
`);

const insertFee = db.prepare(`
  INSERT INTO fee_reminders (student_id, amount_text, due_date, paid)
  VALUES (@student_id, @amount_text, @due_date, @paid)
`);

const alreadySeeded = db.prepare("SELECT COUNT(*) AS n FROM courses").get().n > 0;

if (alreadySeeded) {
  console.log("Courses already exist — skipping seed (delete the .db file to reset).");
  process.exit(0);
}

const seedAll = db.transaction(() => {
  const courses = [
    {
      name: "Foundations of Drawing",
      category: "Drawing",
      age_group: "8-14 yrs",
      description: "Pencil, charcoal and perspective basics for young beginners.",
      fee_text: "₹2,800 / month",
      duration_text: "8-week batch · 2 classes/week",
    },
    {
      name: "Watercolour Painting",
      category: "Painting",
      age_group: "Teens & Adults",
      description: "Wash techniques, colour mixing, landscapes and still life.",
      fee_text: "₹3,500 / month",
      duration_text: "8-week batch · 2 classes/week",
    },
    {
      name: "Pottery & Clay Studio",
      category: "Pottery",
      age_group: "12 yrs & up",
      description: "Hand-building and wheel-throwing, glazing and firing included.",
      fee_text: "₹4,200 / month",
      duration_text: "6-week batch · 1 class/week",
    },
    {
      name: "Little Picassos",
      category: "Kids Art",
      age_group: "4-7 yrs",
      description: "Colours, textures and free-form creative play for the very young.",
      fee_text: "₹2,200 / month",
      duration_text: "Ongoing · 1 class/week",
    },
  ];

  const courseIds = {};
  for (const c of courses) {
    const info = insertCourse.run(c);
    courseIds[c.name] = info.lastInsertRowid;
  }

  const slots = [
    { course: "Foundations of Drawing", label: "Sat, 9 Aug · 10:00 AM", capacity: 6 },
    { course: "Foundations of Drawing", label: "Wed, 6 Aug · 4:30 PM", capacity: 6 },
    { course: "Watercolour Painting", label: "Sat, 9 Aug · 12:00 PM", capacity: 6 },
    { course: "Pottery & Clay Studio", label: "Sun, 10 Aug · 11:00 AM", capacity: 4 },
    { course: "Little Picassos", label: "Sat, 9 Aug · 9:00 AM", capacity: 8 },
  ];
  for (const s of slots) {
    insertSlot.run({ course_id: courseIds[s.course], label: s.label, capacity: s.capacity });
  }

  const schedule = [
    { course: "Foundations of Drawing", day_of_week: "Wednesday", time_label: "4:30 PM - 6:00 PM", room: "Studio A" },
    { course: "Foundations of Drawing", day_of_week: "Saturday", time_label: "10:00 AM - 11:30 AM", room: "Studio A" },
    { course: "Watercolour Painting", day_of_week: "Tuesday", time_label: "5:00 PM - 6:30 PM", room: "Studio B" },
    { course: "Watercolour Painting", day_of_week: "Saturday", time_label: "12:00 PM - 1:30 PM", room: "Studio B" },
    { course: "Pottery & Clay Studio", day_of_week: "Sunday", time_label: "11:00 AM - 1:00 PM", room: "Pottery Shed" },
    { course: "Little Picassos", day_of_week: "Saturday", time_label: "9:00 AM - 10:00 AM", room: "Studio C" },
  ];
  for (const s of schedule) {
    insertSchedule.run({ course_id: courseIds[s.course], day_of_week: s.day_of_week, time_label: s.time_label, room: s.room });
  }

  // Sample enrolled student — replace/remove, or bulk-import real ones.
  // NOTE: phone must be digits only with country code, no "+", e.g. 919876543210
  const demoStudent = { phone: "919999999999", name: "Aanya Kapoor", course_id: courseIds["Watercolour Painting"] };
  const info = insertStudent.run(demoStudent);
  const studentId = info.lastInsertRowid || db.prepare("SELECT id FROM students WHERE phone = ?").get(demoStudent.phone).id;

  insertFee.run({ student_id: studentId, amount_text: "₹3,500", due_date: "2026-08-10", paid: 0 });
});

seedAll();
console.log("Seed complete: 4 courses, 5 trial slots, class schedule, 1 demo student with a pending fee.");
